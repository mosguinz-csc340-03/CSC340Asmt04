#pragma once

#include <string>
#include <iostream>
#include <memory>
#include <vector>
#include <cstdlib>

#include "LinkedBag.h"
#include "LinkedBag.cpp"
#include "LinkedBag340.cpp"

using namespace std;
